package com.example.demo.controller;

import com.example.demo.dto.CheapestRoomDto;
import com.example.demo.entity.Hotel;
import com.example.demo.service.HotelService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RestController
@RequestMapping("/hotel")
@Slf4j
public class HotelController {
    @Autowired
    private HotelService hotelService;

    @PostMapping
    ResponseEntity<Object> create(@RequestBody Hotel newHotel){
        return new ResponseEntity<>(hotelService.create(newHotel), HttpStatus.CREATED);
    }

    @GetMapping("/find/all")
    ResponseEntity<Object> findAll(){
        return new ResponseEntity<>(hotelService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/search")
    ResponseEntity<Object> findBy(@RequestParam(defaultValue = "name") String criteria, @RequestParam(defaultValue = "A") String value, @RequestParam(defaultValue = "asc") String order){
        return  new ResponseEntity<>(hotelService.findBy(criteria, value, order), HttpStatus.OK);
    }


    @GetMapping("/cheapest")
    ResponseEntity<CheapestRoomDto> findCheap(@RequestParam String category, @RequestParam String startDate, @RequestParam String endDate){
        return new ResponseEntity<>(hotelService.findCheapestHotel(category, LocalDate.parse(startDate, DateTimeFormatter.ofPattern("yyyy-mm-dd")), LocalDate.parse(endDate, DateTimeFormatter.ofPattern("yyyy-mm-dd"))), HttpStatus.OK);
    }


}
