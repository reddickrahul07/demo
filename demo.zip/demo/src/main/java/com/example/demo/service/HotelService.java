package com.example.demo.service;

import com.example.demo.dto.CheapestRoomDto;
import com.example.demo.entity.Hotel;

import java.time.LocalDate;
import java.util.List;

public interface HotelService {
    Hotel create(Hotel newHotel);
    List<Hotel> findAll();
    List<Hotel> findBy(String name, String value, String order);
    //Hotel findCheapestHotel();
    CheapestRoomDto findCheapestHotel(String category, LocalDate startDate, LocalDate endDate);
}
