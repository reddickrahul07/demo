package com.example.demo.repository;

import com.example.demo.dto.CheapestRoomDto;
import com.example.demo.entity.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {

    @Query("select new com.example.demo.dto.CheapestRoomDto(rp.categoryId, rc.category, rp.price)" +
            " from RoomPrice rp" +
            " inner join RoomCategory rc on rp.categoryId = rc.id" +
            " where rc.category = :category" +
            " order by rp.price asc")
    List<CheapestRoomDto> findCheapestRoomBy(@Param("category") String category);
}
