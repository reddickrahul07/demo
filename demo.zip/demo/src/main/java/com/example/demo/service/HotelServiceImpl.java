package com.example.demo.service;

import com.example.demo.dto.CheapestRoomDto;
import com.example.demo.entity.Holiday;
import com.example.demo.entity.Hotel;
import com.example.demo.entity.RoomPrice;
import com.example.demo.repository.HolidayRepository;
import com.example.demo.repository.HotelRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HotelServiceImpl implements HotelService{
    @Autowired
    private HotelRepository hotelRepository;
    @Autowired
    private HolidayRepository holidayRepository;
    private final EntityManager em;

    @Override
    public Hotel create(Hotel newHotel) {
        return hotelRepository.save(newHotel);
    }

    @Override
    public List<Hotel> findAll() {
        return hotelRepository.findAll();
    }

    @Override
    public List<Hotel> findBy(String criteria, String value, String order){
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Hotel> cq = cb.createQuery(Hotel.class);
        Root<Hotel> hotelRoot = cq.from(Hotel.class);
        List<Predicate> predicates = new ArrayList<>();
        if(criteria != null){
            if(criteria.equalsIgnoreCase("name")){
                predicates.add(cb.like(hotelRoot.get("name"), "%"+value+"%"));
            }

            if(criteria.equalsIgnoreCase("rate")){
                if(order.equalsIgnoreCase("desc")){
                    predicates.add(cb.ge(hotelRoot.get("rate"), Double.parseDouble(value)));
                }else{
                    predicates.add(cb.le(hotelRoot.get("rate"), Double.parseDouble(value)));
                }
            }
        }

        cq.where(predicates.toArray(new Predicate[0]));
        List<Hotel> hotelList = em.createQuery(cq).getResultList();
        if(criteria != null && criteria.equalsIgnoreCase("rate")){
            if(order.equalsIgnoreCase("desc")){
                hotelList.sort(Comparator.comparingDouble(Hotel::getRate).reversed());
            }else{
                hotelList.sort(Comparator.comparingDouble(Hotel::getRate));
            }
        }
        return hotelList;
    }

    @Override
    public CheapestRoomDto findCheapestHotel(String category, LocalDate startDate, LocalDate endDate) {
        Holiday holiday = holidayRepository.findByDateBetween(startDate, endDate).stream().findFirst().orElse(null);
        if(holiday != null){
            return hotelRepository.findCheapestRoomBy("GOLD")
                    .stream()
                    .map(
                            r->new CheapestRoomDto(r.getCategoryId(), r.getCategory(), r.getPrice() + (r.getPrice() * (holiday.getInflateRatio()/100)))
                    )
                    .toList().stream().sorted(Comparator.comparingDouble(CheapestRoomDto::getPrice)).findFirst().get();
        }
        return hotelRepository.findCheapestRoomBy("GOLD").stream().sorted(Comparator.comparingDouble(CheapestRoomDto::getPrice)).findFirst().get();
    }
}
