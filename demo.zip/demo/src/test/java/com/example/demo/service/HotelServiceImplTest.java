package com.example.demo.service;

import com.example.demo.dto.CheapestRoomDto;
import com.example.demo.entity.*;
import com.example.demo.repository.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;

@SpringBootTest
class HotelServiceImplTest {

    @Autowired private RoomTypeRepository roomTypeRepository;
    @Autowired private CustomerRepository customerRepository;
    @Autowired private RoomCategoryRepository roomCategoryRepository;
    @Autowired private RoomPriceRepository roomPriceRepository;
    @Autowired private BookedRoomRepository bookedRoomRepository;
    @Autowired private HolidayRepository holidayRepository;

    @Autowired
    private HotelService underTest;

    @BeforeEach
    public void setup(){
        roomCategoryRepository.deleteAll();
        roomPriceRepository.deleteAll();
        holidayRepository.deleteAll();

        // create room categories
        RoomCategory category1 = RoomCategory.builder()
                .category("GOLD")
                .build();
        RoomCategory category2 = RoomCategory.builder()
                .category("SILVER")
                .build();
        RoomCategory category3 = RoomCategory.builder()
                .category("PLATINUM")
                .build();

        // create room prices
        RoomPrice roomPrice1 = RoomPrice.builder()
                .categoryId(1L)
                .price(120.0)
                .hotelId(1L)
                .build();
        RoomPrice roomPrice2 = RoomPrice.builder()
                .categoryId(2L)
                .price(80.0)
                .hotelId(1L)
                .build();
        RoomPrice roomPrice3 = RoomPrice.builder()
                .categoryId(3L)
                .price(140.0)
                .hotelId(1L)
                .build();

        RoomPrice roomPrice4 = RoomPrice.builder()
                .categoryId(1L)
                .price(110.0)
                .hotelId(2L)
                .build();
        RoomPrice roomPrice5 = RoomPrice.builder()
                .categoryId(2L)
                .price(90.0)
                .hotelId(2L)
                .build();
        RoomPrice roomPrice6 = RoomPrice.builder()
                .categoryId(3L)
                .price(130.0)
                .hotelId(2L)
                .build();

        // create room types
        RoomType roomType1 = RoomType.builder()
                .categoryId(3L).build();
        RoomType roomType2 = RoomType.builder()
                .categoryId(2L).build();
        RoomType roomType3 = RoomType.builder()
                .categoryId(1L).build();
        RoomType roomType4 = RoomType.builder()
                .categoryId(1L).build();
        RoomType roomType5 = RoomType.builder()
                .categoryId(3L).build();

        // create holiday

        Holiday holiday1 = Holiday.builder()
                .date(LocalDate.of(2024, 6, 22))
                .inflateRatio(20.0).build();

        roomCategoryRepository.saveAll(List.of(category1, category2, category3));
        roomPriceRepository.saveAll(List.of(roomPrice1, roomPrice2, roomPrice3, roomPrice4, roomPrice5, roomPrice6));
        holidayRepository.save(holiday1);

    }

    @Test
    public void testFindCheapestHotel(){
        CheapestRoomDto cheapestRoomDto = underTest.findCheapestHotel("GOLD", LocalDate.of(2024, 06, 20), LocalDate.of(2024, 06, 23));
        Assertions.assertEquals(132.0, cheapestRoomDto.getPrice());
        Assertions.assertEquals("GOLD", cheapestRoomDto.getCategory());
    }

}