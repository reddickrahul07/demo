


INSERT INTO `reservation_system`.`customer` (`id`, `address`, `contact_number`, `name`) VALUES ('1', 'Pune', '234234242', 'A');
INSERT INTO `reservation_system`.`customer` (`id`, `address`, `contact_number`, `name`) VALUES ('2', 'Mumbai', '453424234', 'B');
INSERT INTO `reservation_system`.`customer` (`id`, `address`, `contact_number`, `name`) VALUES ('3', 'Nashik', '766433432', 'C');
INSERT INTO `reservation_system`.`customer` (`id`, `address`, `contact_number`, `name`) VALUES ('4', 'Delhi', '954563453', 'D');


INSERT INTO `reservation_system`.`room_category` (`id`, `category`) VALUES ('1', 'GOLD');
INSERT INTO `reservation_system`.`room_category` (`id`, `category`) VALUES ('2', 'SILVER');
INSERT INTO `reservation_system`.`room_category` (`id`, `category`) VALUES ('3', 'PLATINUM');

INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('120', '1', '1', '1');
INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('80',  '2', '1', '2');
INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('140', '3', '1', '3');

INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('110', '1', '2', '3');
INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('90',  '2', '2', '4');
INSERT INTO `reservation_system`.`room_price` (`price`, `category_id`, `hotel_id`, `id`) VALUES ('130', '3', '2', '5');


